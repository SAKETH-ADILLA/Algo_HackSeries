from pyteal import *

def recurring_payment_contract(receiver: str, amount: int, interval: int) -> Expr:
    payment_key = Bytes("last_payment")

    return Seq([
        App.globalPut(payment_key, Int(0)),
        If(
            And(
                Global.latest_timestamp() > App.globalGet(payment_key) + Int(interval),
                Txn.application_args[0] == Bytes("pay")
            ),
            Seq([
                InnerTxnBuilder.Begin(),
                InnerTxnBuilder.SetFields({
                    TxnField.type_enum: TxnType.Payment,
                    TxnField.receiver: Addr(receiver),
                    TxnField.amount: Int(amount),
                }),
                InnerTxnBuilder.Submit(),
                App.globalPut(payment_key, Global.latest_timestamp()),
            ]),
        ),
        Approve()
    ])

if __name__ == "__main__":
    receiver_address = "RECEIVER_ALGORAND_ADDRESS"
    amount = 100000  # in microAlgos
    interval = 60 * 60 * 24 * 7  # 1 week

    print(compileTeal(recurring_payment_contract(receiver_address, amount, interval), mode=Mode.Application))
